This is a mod for starsector (https://starsector.fandom.com) with a collection of cruiser gunships ships to the game which are more or less balanced and fun to play. Enjoy!
